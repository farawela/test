#!/bin/bash
# =============================================================================
#  NetSeeker — Installation Script
#  Copyright (c) 2024 NetSeeker. All rights reserved.
#  For authorized penetration testing use only.
# =============================================================================

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

TOOL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="$TOOL_DIR/install.log"
ERRORS=0

log()  { echo "$(date '+%H:%M:%S') $*" >> "$LOG_FILE"; }
ok()   { echo -e "${GREEN}  [✓]${NC} $*"; log "OK: $*"; }
fail() { echo -e "${RED}  [✗]${NC} $*"; log "FAIL: $*"; ERRORS=$((ERRORS+1)); }
warn() { echo -e "${YELLOW}  [!]${NC} $*"; log "WARN: $*"; }
info() { echo -e "${CYAN}  [*]${NC} $*"; log "INFO: $*"; }

echo ""
echo -e "${BOLD}${CYAN}"
echo "  ███╗   ██╗███████╗████████╗███████╗███████╗███████╗██╗  ██╗███████╗██████╗"
echo "  ████╗  ██║██╔════╝╚══██╔══╝██╔════╝██╔════╝██╔════╝██║ ██╔╝██╔════╝██╔══██╗"
echo "  ██╔██╗ ██║█████╗     ██║   ███████╗█████╗  █████╗  █████╔╝ █████╗  ██████╔╝"
echo "  ██║╚██╗██║██╔══╝     ██║   ╚════██║██╔══╝  ██╔══╝  ██╔═██╗ ██╔══╝  ██╔══██╗"
echo "  ██║ ╚████║███████╗   ██║   ███████║███████╗███████╗██║  ██╗███████╗██║  ██║"
echo "  ╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝"
echo -e "${NC}"
echo -e "${BOLD}  Installation Script${NC}"
echo -e "  Log: $LOG_FILE"
echo ""
echo "  $(date)"
echo "  ──────────────────────────────────────────────────────"
echo ""

if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}[!] Must be run as root: sudo bash install.sh${NC}"
    exit 1
fi

[[ -f /etc/os-release ]] && source /etc/os-release
info "OS: ${PRETTY_NAME:-Unknown}"

echo ""
echo -e "${BOLD}  [1/5] Package Lists${NC}"
echo "  ──────────────────────────────────────────────────────"
apt-get update -qq >> "$LOG_FILE" 2>&1 && ok "Package lists updated" || warn "apt-get update failed"

echo ""
echo -e "${BOLD}  [2/5] Python Runtime${NC}"
echo "  ──────────────────────────────────────────────────────"

command -v python3 &>/dev/null && ok "python3: $(python3 --version 2>&1)" || {
    apt-get install -y python3 python3-dev -qq >> "$LOG_FILE" 2>&1 && ok "python3 installed" || fail "python3 install failed"
}
command -v pip3 &>/dev/null && ok "pip3: found" || {
    apt-get install -y python3-pip -qq >> "$LOG_FILE" 2>&1 && ok "pip3 installed" || fail "pip3 install failed"
}
apt-get install -y python3-dev libssl-dev libffi-dev build-essential -qq >> "$LOG_FILE" 2>&1 && ok "Build dependencies installed" || warn "Some build deps failed"

echo ""
echo -e "${BOLD}  [3/5] System Tools${NC}"
echo "  ──────────────────────────────────────────────────────"

command -v nmap &>/dev/null && ok "nmap: $(nmap --version 2>&1 | head -1)" || {
    apt-get install -y nmap -qq >> "$LOG_FILE" 2>&1 && ok "nmap installed" || fail "nmap install failed"
}
command -v nslookup &>/dev/null && ok "nslookup: found" || {
    apt-get install -y dnsutils -qq >> "$LOG_FILE" 2>&1 && ok "dnsutils installed" || fail "dnsutils install failed"
}

CHROME_BIN=""
for bin in google-chrome chromium-browser chromium; do
    command -v "$bin" &>/dev/null && { CHROME_BIN="$bin"; ok "Chrome: $bin"; break; }
done
[[ -z "$CHROME_BIN" ]] && warn "Chrome not found — screenshots disabled. Install: sudo apt install chromium-browser"

command -v searchsploit &>/dev/null && ok "searchsploit: found (optional)" || {
    apt-get install -y exploitdb -qq >> "$LOG_FILE" 2>&1 && ok "searchsploit installed (optional)" || warn "searchsploit unavailable (optional)"
}

echo ""
echo -e "${BOLD}  [4/5] Python Packages${NC}"
echo "  ──────────────────────────────────────────────────────"

REQ="$TOOL_DIR/requirements.txt"
if [[ ! -f "$REQ" ]]; then
    fail "requirements.txt not found"
else
    # Install packages — ignore known Ubuntu metadata warnings that cause false failures
    pip3 install --break-system-packages -r "$REQ" -q >> "$LOG_FILE" 2>&1 ||     pip3 install -r "$REQ" -q >> "$LOG_FILE" 2>&1 || true

    ok "Python packages installation attempted — verifying below"

    # Verify using correct Python import names (pip name != import name for some packages)
    declare -A IMPORT_MAP
    IMPORT_MAP["beautifulsoup4"]="bs4"
    IMPORT_MAP["aiohttp"]="aiohttp"
    IMPORT_MAP["selenium"]="selenium"
    IMPORT_MAP["lxml"]="lxml"
    IMPORT_MAP["pysmb"]="smb"

    while IFS= read -r line; do
        [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
        pkg=$(echo "$line" | sed 's/[>=<].*//' | tr -d ' ')
        import_name="${IMPORT_MAP[$pkg]:-${pkg//-/_}}"
        if python3 -c "import $import_name" 2>/dev/null; then
            ok "  $pkg"
        else
            fail "  $pkg — import failed (tried: import $import_name)"
        fi
    done < "$REQ"
fi

echo ""
echo -e "${BOLD}  [5/5] Tool Configuration${NC}"
echo "  ──────────────────────────────────────────────────────"

SCRIPT="$TOOL_DIR/netseeker.py"
[[ -f "$SCRIPT" ]] && { chmod +x "$SCRIPT"; ok "netseeker.py is executable"; } || fail "netseeker.py not found"

DB="$TOOL_DIR/db/apps.json"
if [[ -f "$DB" ]]; then
    COUNT=$(python3 -c "import json; print(len(json.load(open('$DB'))['applications']))" 2>/dev/null || echo "?")
    ok "Database: $COUNT applications loaded"
else
    fail "Database not found: $DB"
fi

mkdir -p "$TOOL_DIR/output"
ok "Output directory ready"

if [[ ! -L /usr/local/bin/netseeker ]]; then
    ln -sf "$SCRIPT" /usr/local/bin/netseeker
    ok "netseeker added to PATH"
else
    ok "netseeker already in PATH"
fi

python3 "$SCRIPT" --help >> "$LOG_FILE" 2>&1 && ok "Tool self-check passed" || warn "Tool self-check failed — see $LOG_FILE"

echo ""
echo "  ══════════════════════════════════════════════════════"
if [[ $ERRORS -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}  Installation completed successfully.${NC}"
else
    echo -e "${YELLOW}${BOLD}  Installation completed with $ERRORS error(s). See: $LOG_FILE${NC}"
fi
echo ""
echo -e "  ${BOLD}Usage:${NC}"
echo "    sudo python3 netseeker.py <domain>"
echo "    sudo python3 netseeker.py --hosts hosts.txt"
echo "    sudo netseeker <domain>"
echo ""
echo "  $(date)"
echo "  ══════════════════════════════════════════════════════"
echo ""
