#!/usr/bin/env python3
# Copyright (c) 2024 NetSeeker. All rights reserved.
# Unauthorized copying, distribution, or modification is prohibited.
# For authorized penetration testing use only.

import asyncio
import argparse
import html as _html
import subprocess
import socket
import sys
import os
import re
import json
import ssl
import ipaddress
from datetime import datetime
from pathlib import Path
_missing = []
try:
    import aiohttp
except ImportError:
    _missing.append(('aiohttp', 'pip3 install aiohttp --break-system-packages'))
try:
    from bs4 import BeautifulSoup
except ImportError:
    _missing.append(('beautifulsoup4', 'pip3 install beautifulsoup4 --break-system-packages'))
if _missing:
    print('\n[!] Missing required Python packages:\n')
    for pkg, cmd in _missing:
        print(f'    {pkg}')
        print(f'    Install: {cmd}\n')
    print('Fix the above then re-run NetSeeker.\n')
    sys.exit(1)
_smb_available = False
try:
    from smb.SMBConnection import SMBConnection
    _smb_available = True
except ImportError:
    pass
TOOL_DIR = Path(__file__).parent
DB_PATH = TOOL_DIR / 'db' / 'apps.json'
OUTPUT_DIR = TOOL_DIR / 'output'
NMAP_MAX_CONCURRENT = 5
HTTP_TIMEOUT = 8
SCAN_TIMEOUT = 2
XLARGE_PORTS = [80, 81, 300, 443, 591, 593, 832, 981, 1010, 1311, 2082, 2087, 2095, 2096, 2480, 3000, 3128, 3333, 4243, 4567, 4711, 4712, 4993, 5000, 5104, 5108, 5800, 6543, 7000, 7396, 7474, 8000, 8001, 8008, 8014, 8042, 8069, 8080, 8081, 8088, 8090, 8091, 8118, 8123, 8172, 8222, 8243, 8280, 8281, 8333, 8443, 8500, 8834, 8880, 8888, 8983, 9000, 9043, 9060, 9080, 9090, 9091, 9200, 9443, 9800, 9981, 12443, 16080, 18091, 18092, 20720, 28017]
HTTPS_PORTS = {443, 832, 981, 1311, 2087, 2096, 4993, 5108, 8243, 8333, 8443, 8834, 9043, 9443, 12443}
SMB_PORTS = [445, 139]
SMB_TIMEOUT = 5
IS_WINDOWS = sys.platform == 'win32'

def normalize_url(scheme, host, port):
    if scheme == 'https' and port == 443:
        return f'https://{host}'
    if scheme == 'http' and port == 80:
        return f'http://{host}'
    return f'{scheme}://{host}:{port}'
VERSION_ENDPOINTS = ['/version', '/api/version', '/api/v1/version', '/api/v2/version', '/rest/v1/version', '/about', '/api/about', '/api/system/info', '/api/system/version', '/info', '/status', '/health', '/manager/text/serverinfo', '/api/v4/version', '/?rest_route=/', '/rest/v1', '/license/', '/api/v1/info', '/buildinfo']
VERSION_PATTERNS = ['(?i)version[\\s:"]+v?(\\d+\\.\\d+[\\.\\d]*)', '(?i)firmware[\\s:"]+v?(\\d+\\.\\d+[\\.\\d]*)', '(?i)release[\\s:"]+v?(\\d+\\.\\d+[\\.\\d]*)', '(?i)build[\\s:"]+v?([\\d.]+(?:R[\\d.]+)?)', '(?i)v(\\d+\\.\\d+\\.\\d+[\\.\\d]*)', '(?i)"version"\\s*:\\s*"v?(\\d+\\.\\d+[\\.\\d]*[^"]*?)"', '(?i)"firmwareVersion"\\s*:\\s*"(\\d+\\.\\d+[\\.\\d]*)"', '(?i)"buildVersion"\\s*:\\s*"([^"]+)"', '(?i)"softwareVersion"\\s*:\\s*"([^"]+)"', '(?i)(?:^|\\s)v?(\\d+\\.\\d+\\.\\d+(?:\\.\\d+)?)(?:\\s|$)']
VERSION_HEADERS = ['X-Jenkins', 'X-Powered-By', 'X-Generator', 'X-Version', 'X-App-Version', 'X-Firmware-Version', 'X-Build', 'X-Release', 'Server']
META_PATTERNS = ['(?i)<meta[^>]+name=["\\\']generator["\\\'][^>]+content=["\\\']([^"\\\']+)["\\\']', '(?i)<meta[^>]+content=["\\\']([^"\\\']+)["\\\'][^>]+name=["\\\']generator["\\\']', '(?i)<meta[^>]+name=["\\\']version["\\\'][^>]+content=["\\\']([^"\\\']+)["\\\']']

class C:
    RED = '\x1b[91m'
    GREEN = '\x1b[92m'
    YELLOW = '\x1b[93m'
    BLUE = '\x1b[94m'
    CYAN = '\x1b[96m'
    WHITE = '\x1b[97m'
    BOLD = '\x1b[1m'
    RESET = '\x1b[0m'
    GRAY = '\x1b[90m'
    PURPLE = '\x1b[95m'

def banner():
    print(f'{C.CYAN}{C.BOLD}\n ███╗   ██╗███████╗████████╗███████╗███████╗███████╗██╗  ██╗███████╗██████╗\n ████╗  ██║██╔════╝╚══██╔══╝██╔════╝██╔════╝██╔════╝██║ ██╔╝██╔════╝██╔══██╗\n ██╔██╗ ██║█████╗     ██║   ███████╗█████╗  █████╗  █████╔╝ █████╗  ██████╔╝\n ██║╚██╗██║██╔══╝     ██║   ╚════██║██╔══╝  ██╔══╝  ██╔═██╗ ██╔══╝  ██╔══██╗\n ██║ ╚████║███████╗   ██║   ███████║███████╗███████╗██║  ██╗███████╗██║  ██║\n ╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝\n{C.RESET}{C.GRAY}\n  DC Discovery → Network Mapping → Web Fingerprinting\n  For authorized penetration testing only\n{C.RESET}')

def section(title):
    sep60 = '─' * 60
    print(f'\n{C.BOLD}{C.BLUE}{sep60}{C.RESET}')
    print(f'{C.BOLD}{C.BLUE}  {title}{C.RESET}')
    sep60 = '─' * 60
    print(f'{C.BOLD}{C.BLUE}{sep60}{C.RESET}\n')

def check_root():
    if os.geteuid() != 0:
        print(f'{C.RED}[!] NetSeeker must be run as root for full nmap capabilities.{C.RESET}')
        print(f'    Run: sudo python3 netseeker.py <domain>')
        sys.exit(1)

def check_dependencies():
    import shutil
    import importlib
    print(f'{C.CYAN}[*]{C.RESET} Running preflight checks...')
    all_ok = True
    system_tools = {'nmap': 'sudo apt install nmap', 'nslookup': 'sudo apt install dnsutils'}
    for tool, install_cmd in system_tools.items():
        if shutil.which(tool):
            if tool == 'nmap':
                try:
                    result = subprocess.run(['nmap', '--version'], capture_output=True, text=True, timeout=5)
                    version_line = result.stdout.splitlines()[0] if result.stdout else ''
                    print(f'{C.GREEN}    [+]{C.RESET} {tool}: {version_line}')
                except Exception:
                    print(f'{C.GREEN}    [+]{C.RESET} {tool}: found')
            else:
                print(f'{C.GREEN}    [+]{C.RESET} {tool}: found')
        else:
            print(f'{C.RED}    [!]{C.RESET} {tool}: NOT FOUND')
            print(f'         Install: {install_cmd}')
            all_ok = False
    python_packages = {'aiohttp': 'pip3 install aiohttp --break-system-packages', 'bs4': 'pip3 install beautifulsoup4 --break-system-packages', 'ipaddress': None, 'asyncio': None, 'ssl': None, 'json': None, 'subprocess': None, 'socket': None}
    for pkg, install_cmd in python_packages.items():
        try:
            importlib.import_module(pkg)
            if install_cmd:
                print(f'{C.GREEN}    [+]{C.RESET} python:{pkg}: found')
        except ImportError:
            print(f'{C.RED}    [!]{C.RESET} python:{pkg}: NOT FOUND')
            if install_cmd:
                print(f'         Install: {install_cmd}')
            all_ok = False
    if DB_PATH.exists():
        try:
            with open(DB_PATH) as f:
                db = json.load(f)
            app_count = len(db.get('applications', {}))
            print(f'{C.GREEN}    [+]{C.RESET} apps.json: {app_count} applications loaded')
        except Exception as e:
            print(f'{C.RED}    [!]{C.RESET} apps.json: corrupted — {e}')
            all_ok = False
    else:
        print(f'{C.RED}    [!]{C.RESET} apps.json: NOT FOUND at {DB_PATH}')
        print(f'         Make sure db/apps.json exists in the tool directory')
        all_ok = False
    import shutil as _shutil
    if _shutil.which('searchsploit'):
        print(f'{C.GREEN}    [+]{C.RESET} searchsploit: found (optional)')
    else:
        print(f'{C.GRAY}    [-]{C.RESET} searchsploit: not found (optional — install with: sudo apt install exploitdb)')
    if not all_ok:
        print(f'\n{C.RED}[!] Preflight checks failed. Fix the issues above and retry.{C.RESET}')
        sys.exit(1)
    print(f'{C.GREEN}[+]{C.RESET} All preflight checks passed.\n')

def load_database():
    if not DB_PATH.exists():
        print(f'{C.RED}[!] Database not found at {DB_PATH}{C.RESET}')
        print(f'    Make sure apps.json is in the db/ directory')
        sys.exit(1)
    with open(DB_PATH) as f:
        return json.load(f)['applications']

def resolve_hostname(hostname):
    try:
        return socket.gethostbyname(hostname.rstrip('.'))
    except Exception:
        return None

def run_nslookup_srv(query):
    try:
        result = subprocess.run(['nslookup', '-type=srv', query], capture_output=True, text=True, timeout=15)
        return result.stdout + result.stderr
    except Exception as e:
        return ''

def parse_srv_records(output):
    hostnames = set()
    patterns = ['service\\s*=\\s*\\d+\\s+\\d+\\s+\\d+\\s+([\\w\\-\\.]+)', 'svr hostname\\s*=\\s*([\\w\\-\\.]+)', '(\\w[\\w\\-\\.]+)\\s+internet address']
    for pattern in patterns:
        matches = re.findall(pattern, output, re.IGNORECASE)
        for m in matches:
            hostname = m.rstrip('.')
            if hostname and '.' in hostname:
                hostnames.add(hostname)
    return hostnames

async def resolve_computers(computer_file, domain, batch_size=50, batch_delay=0.5):
    section('PHASE 1 — COMPUTER NAME RESOLUTION')
    with open(computer_file) as f:
        names = [l.strip() for l in f if l.strip() and (not l.startswith('#'))]
    domain = domain.strip().lower().lstrip('.')
    print(f'{C.CYAN}[*]{C.RESET} Loaded {C.BOLD}{len(names)}{C.RESET} computer names')
    print(f'{C.CYAN}[*]{C.RESET} Appending domain: {C.BOLD}.{domain}{C.RESET}')
    print(f'{C.CYAN}[*]{C.RESET} Batch size: {batch_size} | Delay: {batch_delay}s between batches')
    print()
    resolved = []
    failed = 0
    loop = asyncio.get_event_loop()

    def resolve_one(name):
        fqdn = f'{name}.{domain}' if not name.lower().endswith(f'.{domain}') else name
        try:
            ip = socket.gethostbyname(fqdn)
            return (name, fqdn, ip)
        except Exception:
            return (name, fqdn, None)
    total = len(names)
    done = 0
    batches = [names[i:i + batch_size] for i in range(0, total, batch_size)]
    for batch_num, batch in enumerate(batches, 1):
        tasks = [loop.run_in_executor(None, resolve_one, n) for n in batch]
        results = await asyncio.gather(*tasks)
        for name, fqdn, ip in results:
            done += 1
            if ip:
                resolved.append({'hostname': fqdn, 'short': name, 'ip': ip})
                print(f'{C.GREEN}    [+]{C.RESET} {name:35s} → {ip}')
            else:
                failed += 1
        progress = int(done / total * 50)
        bar = '█' * progress + '░' * (50 - progress)
        print(f'\r    [{bar}] {done}/{total} ({failed} failed)', end='', flush=True)
        if batch_num < len(batches):
            await asyncio.sleep(batch_delay)
    print(f'\n\n{C.GREEN}[+]{C.RESET} Resolved: {C.BOLD}{len(resolved)}{C.RESET} | Failed: {C.YELLOW}{failed}{C.RESET}')
    return resolved

def discover_dcs(domain):
    section('PHASE 1 — DC DISCOVERY')
    srv_queries = [f'_ldap._tcp.{domain}', f'_ldap._tcp.dc._msdcs.{domain}', f'_kerberos._tcp.{domain}', f'_gc._tcp.{domain}', f'_kerberos._tcp.dc._msdcs.{domain}']
    all_hostnames = set()
    for query in srv_queries:
        print(f'{C.CYAN}[*]{C.RESET} Querying SRV: {C.BOLD}{query}{C.RESET}')
        output = run_nslookup_srv(query)
        hostnames = parse_srv_records(output)
        if hostnames:
            for h in hostnames:
                print(f'{C.GREEN}    [+]{C.RESET} Found DC hostname: {C.YELLOW}{h}{C.RESET}')
            all_hostnames.update(hostnames)
        else:
            print(f'{C.GRAY}    [-] No SRV records found{C.RESET}')
    if not all_hostnames:
        print(f'\n{C.RED}[!] No DCs found via SRV records.{C.RESET}')
        print(f'    Trying direct hostname resolution for common DC names...')
        common_names = [f'dc.{domain}', f'dc1.{domain}', f'dc2.{domain}', f'ad.{domain}', f'ldap.{domain}', f'kdc.{domain}']
        for hostname in common_names:
            ip = resolve_hostname(hostname)
            if ip:
                print(f'{C.GREEN}    [+]{C.RESET} Resolved: {hostname} → {ip}')
                all_hostnames.add(hostname)
    if not all_hostnames:
        print(f'{C.RED}[!] No DCs discovered. Exiting.{C.RESET}')
        sys.exit(1)
    print(f'\n{C.CYAN}[*]{C.RESET} Resolving DC hostnames to IPs...')
    dcs = []
    seen_ips = set()
    for hostname in sorted(all_hostnames):
        ip = resolve_hostname(hostname)
        if ip:
            if ip not in seen_ips:
                seen_ips.add(ip)
                dcs.append({'hostname': hostname, 'ip': ip})
                print(f'{C.GREEN}    [+]{C.RESET} {hostname:40s} → {C.BOLD}{ip}{C.RESET}')
            else:
                print(f'{C.GRAY}    [-]{C.RESET} {hostname:40s} → {ip} (duplicate IP, skipping)')
        else:
            print(f'{C.RED}    [!]{C.RESET} {hostname:40s} → Resolution failed')
    if not dcs:
        print(f'{C.RED}[!] No DCs could be resolved. Exiting.{C.RESET}')
        sys.exit(1)
    print(f'\n{C.GREEN}[+]{C.RESET} Discovered {C.BOLD}{len(dcs)}{C.RESET} unique DC(s)')
    return dcs

def get_unique_subnets(dcs):
    subnets = {}
    for dc in dcs:
        ip = dc['ip']
        network = ipaddress.IPv4Network(f'{ip}/24', strict=False)
        subnet_str = str(network)
        if subnet_str not in subnets:
            subnets[subnet_str] = []
        subnets[subnet_str].append(dc)
    return subnets

def parse_nmap_live_hosts(output):
    live = set()
    for line in output.splitlines():
        if 'Nmap scan report for' not in line:
            continue
        m = re.search('\\((\\d+\\.\\d+\\.\\d+\\.\\d+)\\)', line)
        if m:
            live.add(m.group(1))
        else:
            m = re.search('Nmap scan report for (\\d+\\.\\d+\\.\\d+\\.\\d+)', line)
            if m:
                live.add(m.group(1))
    return list(live)

async def scan_subnet(subnet, semaphore):
    async with semaphore:
        print(f'{C.CYAN}[*]{C.RESET} Scanning subnet: {C.BOLD}{subnet}{C.RESET}')
        cmd = ['nmap', '-sn', '-PE', '-PP', '-PM', '-PS22,80,443,445,3389,8080,8443,8888,3306', '-PA80,443,8080', '-PU', '--min-hostgroup', '64', '--min-parallelism', '64', '-T4', '--open', '-oN', '-', subnet]
        try:
            proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=300)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                print(f'{C.YELLOW}    [!]{C.RESET} nmap timed out on {subnet} after 300s')
                return (subnet, [])
            output = stdout.decode(errors='replace')
            live_hosts = parse_nmap_live_hosts(output)
            print(f'{C.GREEN}    [+]{C.RESET} {subnet} → {C.BOLD}{len(live_hosts)}{C.RESET} live host(s)')
            for ip in sorted(live_hosts, key=lambda x: ipaddress.IPv4Address(x)):
                print(f'{C.GREEN}        ✓{C.RESET} {ip}')
            return (subnet, live_hosts)
        except Exception as e:
            print(f'{C.RED}    [!]{C.RESET} Failed to scan {subnet}: {e}')
            return (subnet, [])

async def scan_all_subnets(subnets):
    section('PHASE 2 — NETWORK MAPPING')
    semaphore = asyncio.Semaphore(NMAP_MAX_CONCURRENT)
    tasks = [scan_subnet(subnet, semaphore) for subnet in subnets]
    results = await asyncio.gather(*tasks)
    all_live = []
    subnet_results = {}
    for subnet, hosts in results:
        subnet_results[subnet] = hosts
        all_live.extend(hosts)
    seen = set()
    unique_live = []
    for ip in all_live:
        if ip not in seen:
            seen.add(ip)
            unique_live.append(ip)
    unique_live.sort(key=lambda x: ipaddress.IPv4Address(x))
    print(f'\n{C.GREEN}[+]{C.RESET} Total live hosts discovered: {C.BOLD}{len(unique_live)}{C.RESET}')
    return (unique_live, subnet_results)

async def scan_port(host, port, semaphore):
    async with semaphore:
        try:
            conn = asyncio.open_connection(host, port)
            reader, writer = await asyncio.wait_for(conn, timeout=SCAN_TIMEOUT)
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            return port
        except Exception:
            return None

async def scan_host_ports(host):
    semaphore = asyncio.Semaphore(50)
    tasks = [scan_port(host, port, semaphore) for port in XLARGE_PORTS]
    results = await asyncio.gather(*tasks)
    return [p for p in results if p is not None]

async def fetch_url(session, url):
    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=HTTP_TIMEOUT), allow_redirects=True, ssl=False) as resp:
            body = await resp.text(errors='replace')
            return {'url': str(resp.url), 'status': resp.status, 'headers': dict(resp.headers), 'body': body[:50000]}
    except Exception:
        return None

async def try_both_schemes(session, host, port):
    schemes = ['https', 'http'] if port in HTTPS_PORTS else ['http', 'https']
    for scheme in schemes:
        url = f'{scheme}://{host}:{port}'
        result = await fetch_url(session, url)
        if result:
            result['scheme'] = scheme
            result['port'] = port
            result['host'] = host
            return result
    return None

def extract_title(body):
    try:
        soup = BeautifulSoup(body, 'html.parser')
        title = soup.find('title')
        return title.text.strip() if title else ''
    except Exception:
        return ''

def match_app(response_data, db):
    if not response_data:
        return (None, None)
    title = extract_title(response_data.get('body', '')).lower()
    headers = {k.lower(): v.lower() for k, v in response_data.get('headers', {}).items()}
    body = response_data.get('body', '').lower()
    best_match = None
    best_score = 0
    for app_key, app_data in db.items():
        score = 0
        fps = app_data.get('fingerprints', {})
        for t in fps.get('title', []):
            if t.lower() in title:
                score += 3
        for header_key, header_vals in fps.get('headers', {}).items():
            hk = header_key.lower()
            if hk in headers:
                if not header_vals:
                    score += 2
                else:
                    for hv in header_vals:
                        if hv.lower() in headers[hk]:
                            score += 2
        for pattern in fps.get('body', []):
            if pattern.lower() in body:
                score += 1
        if score > best_score:
            best_score = score
            best_match = (app_key, app_data)
    if best_score >= 2:
        return best_match
    return (None, None)

def extract_version_from_text(text):
    for pattern in VERSION_PATTERNS:
        match = re.search(pattern, text)
        if match:
            version = match.group(1).strip()
            if len(version) > 20:
                continue
            return version
    return None

def extract_version_from_headers(headers):
    headers_lower = {k.lower(): v for k, v in headers.items()}
    for header in VERSION_HEADERS:
        value = headers_lower.get(header.lower())
        if not value:
            continue
        version = extract_version_from_text(value)
        if version:
            return (version, header)
        match = re.search('(\\d+\\.\\d+[\\.\\d]*)', value)
        if match:
            return (match.group(1), header)
    return (None, None)

def extract_version_from_meta(body):
    for pattern in META_PATTERNS:
        match = re.search(pattern, body)
        if match:
            content = match.group(1).strip()
            version = extract_version_from_text(content)
            if version:
                return (version, f'meta: {content[:50]}')
            if any((c.isdigit() for c in content)):
                return (content[:50], f'meta: {content[:50]}')
    return (None, None)

async def detect_version(session, base_url, main_response):
    headers = main_response.get('headers', {})
    version, source = extract_version_from_headers(headers)
    if version:
        return (version, f'header:{source}')
    body = main_response.get('body', '')
    version, source = extract_version_from_meta(body)
    if version:
        return (version, source)
    version = extract_version_from_text(body)
    if version:
        return (version, 'body:main_page')
    for endpoint in VERSION_ENDPOINTS:
        try:
            await asyncio.sleep(__import__('random').uniform(0.1, 0.3))
            url = base_url.rstrip('/') + endpoint
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=5), allow_redirects=False, ssl=False) as resp:
                if resp.status not in (200, 201):
                    continue
                text = await resp.text(errors='replace')
                if not text.strip():
                    continue
                try:
                    data = json.loads(text)

                    def flatten(obj, prefix=''):
                        items = {}
                        if isinstance(obj, dict):
                            for k, v in obj.items():
                                items.update(flatten(v, f'{prefix}{k}.'))
                        elif isinstance(obj, list):
                            for i, v in enumerate(obj):
                                items.update(flatten(v, f'{prefix}{i}.'))
                        else:
                            items[prefix.rstrip('.')] = str(obj)
                        return items
                    flat = flatten(data)
                    for key, val in flat.items():
                        if any((v in key.lower() for v in ['version', 'firmware', 'build', 'release'])):
                            ver = extract_version_from_text(str(val))
                            if ver:
                                return (ver, f'endpoint:{endpoint}[{key}]')
                except Exception:
                    pass
                version = extract_version_from_text(text)
                if version:
                    return (version, f'endpoint:{endpoint}')
        except Exception:
            continue
    return (None, None)

def detect_version_passive(main_response):
    headers = main_response.get('headers', {})
    version, source = extract_version_from_headers(headers)
    if version:
        return (version, f'header:{source}')
    body = main_response.get('body', '')
    version, source = extract_version_from_meta(body)
    if version:
        return (version, source)
    version = extract_version_from_text(body)
    if version:
        return (version, 'body:main_page')
    return (None, None)

async def fingerprint_host(host, db, session):
    open_ports = await scan_host_ports(host)
    if not open_ports:
        return {'host': host, 'open_ports': [], 'services': []}
    services = []
    for port in open_ports:
        response = await try_both_schemes(session, host, port)
        if not response:
            continue
        status = response.get('status')
        url = normalize_url(response['scheme'], host, port)
        if status and 400 <= status <= 499:
            print(f'{C.GRAY}    [-]{C.RESET} {url} → HTTP {status} (skipped)')
            continue
        title = extract_title(response.get('body', ''))
        server = response.get('headers', {}).get('Server', response.get('headers', {}).get('server', 'Unknown'))
        app_key, app_data = match_app(response, db)
        version, vsource = await detect_version(session, url, response)
        service = {'url': url, 'port': port, 'status': status, 'title': title, 'server': server, 'app_key': app_key, 'app_name': app_data['name'] if app_data else 'Unknown Application', 'version': version, 'version_source': vsource, 'credentials': app_data.get('default_credentials', []) if app_data else [], 'cves': app_data.get('cves', []) if app_data else [], 'screenshot': None}
        if app_data:
            vstr = f' {C.CYAN}v{version}{C.RESET}' if version else f' {C.GRAY}(version unknown){C.RESET}'
            print(f'{C.GREEN}    [+]{C.RESET} {url} → {C.YELLOW}{C.BOLD}{app_data["name"]}{C.RESET}{vstr}')
            cve_ids = [c['id'] for c in app_data.get('cves', [])]
            if cve_ids:
                cve_str = ', '.join(cve_ids)
                print(f'{C.RED}        CVEs: {cve_str}{C.RESET}')
        else:
            print(f'{C.GRAY}    [-]{C.RESET} {url} → Unknown (Title: {(title[:50] if title else "N/A")})')
        services.append(service)
    return {'host': host, 'open_ports': open_ports, 'services': services}

def take_screenshots(services_list, screenshots_dir):
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.chrome.service import Service
        from webdriver_manager.chrome import ChromeDriverManager
        import shutil
    except ImportError as _e:
        print(f'{C.YELLOW}[!]{C.RESET} Missing dependency ({_e}) — skipping screenshots')
        print(f'    Install: pip3 install selenium webdriver-manager --break-system-packages --ignore-installed urllib3')
        return {}
    except Exception as _e:
        print(f'{C.YELLOW}[!]{C.RESET} Unexpected error loading selenium ({_e}) — skipping screenshots')
        return {}
    screenshots_dir.mkdir(parents=True, exist_ok=True)
    chrome_bin = shutil.which('google-chrome') or shutil.which('chromium-browser') or shutil.which('chromium')
    if not chrome_bin:
        print(f'{C.YELLOW}[!]{C.RESET} No Chrome/Chromium found — skipping screenshots')
        return {}
    print(f'{C.CYAN}[*]{C.RESET} Chrome: {chrome_bin}')
    opts = Options()
    opts.binary_location = chrome_bin
    opts.add_argument('--headless=new')
    opts.add_argument('--no-sandbox')
    opts.add_argument('--disable-dev-shm-usage')
    opts.add_argument('--disable-gpu')
    opts.add_argument('--window-size=1280,800')
    opts.add_argument('--ignore-certificate-errors')
    opts.add_argument('--ignore-ssl-errors')
    opts.add_argument('--disable-web-security')
    opts.add_argument('--allow-insecure-localhost')
    opts.add_argument('--log-level=3')
    opts.add_argument('--disable-extensions')
    opts.add_argument('--remote-debugging-port=0')
    results = {}
    try:
        svc = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=svc, options=opts)
        driver.set_page_load_timeout(15)
        for svc_item in services_list:
            url = svc_item['url']
            safe_name = re.sub('[^\\w\\-.]', '_', url.replace('://', '_').replace('/', '_'))
            safe_name = safe_name[:100]
            shot_path = screenshots_dir / f'{safe_name}.png'
            try:
                driver.get(url)
                import time
                time.sleep(2)
                driver.save_screenshot(str(shot_path))
                results[url] = shot_path
                print(f'{C.GREEN}    [+]{C.RESET} Screenshot: {shot_path.name}')
            except Exception as e:
                print(f'{C.YELLOW}    [!]{C.RESET} Screenshot failed for {url}: {e}')
                results[url] = None
        driver.quit()
    except Exception as e:
        print(f'{C.RED}[!]{C.RESET} Chrome failed to start: {e}')
        print(f'    Run: sudo pip3 install webdriver-manager --break-system-packages --ignore-installed urllib3')
    return results

async def run_web_fingerprinting(live_hosts, db, output_dir=None, max_threads=20):
    section('PHASE 3 — WEB FINGERPRINTING')
    print(f'{C.CYAN}[*]{C.RESET} Fingerprinting {C.BOLD}{len(live_hosts)}{C.RESET} live hosts...')
    print(f'{C.YELLOW}[!]{C.RESET} SSL verification disabled for scanning (pentest mode — MitM possible on hostile networks)')
    ssl_ctx = ssl.create_default_context()
    ssl_ctx.check_hostname = False
    ssl_ctx.verify_mode = ssl.CERT_NONE
    connector = aiohttp.TCPConnector(ssl=ssl_ctx, limit=100)
    results = []
    async with aiohttp.ClientSession(connector=connector) as session:
        semaphore = asyncio.Semaphore(max_threads)

        async def bounded(host):
            async with semaphore:
                print(f'{C.BLUE}[*]{C.RESET} Scanning {C.BOLD}{host}{C.RESET}')
                return await fingerprint_host(host, db, session)
        tasks = [bounded(host) for host in live_hosts]
        results = await asyncio.gather(*tasks)
    results = list(results)
    if output_dir:
        screenshots_dir = output_dir / 'screenshots'
        all_services = [s for r in results for s in r.get('services', [])]
        if all_services:
            section('PHASE 4 — SCREENSHOTS')
            print(f'{C.CYAN}[*]{C.RESET} Taking screenshots of {C.BOLD}{len(all_services)}{C.RESET} web services...')
            loop = asyncio.get_event_loop()
            shot_map = await loop.run_in_executor(None, take_screenshots, all_services, screenshots_dir)
            for r in results:
                for svc in r.get('services', []):
                    svc['screenshot'] = shot_map.get(svc['url'])
        else:
            print(f'{C.GRAY}[*]{C.RESET} No live web services to screenshot')
    return results

def smb_enumerate_host(host, username, password, domain):
    result = {
        'host': host,
        'port': 445,
        'smb_open': False,
        'authenticated': False,
        'auth_user': (domain + '\\' + username) if domain else username,
        'shares': [],
        'error': None
    }
    try:
        my_name = socket.gethostname().split('.')[0].upper()
        conn = SMBConnection(
            username, password,
            my_name, host,
            domain=domain or '',
            use_ntlm_v2=True,
            is_direct_tcp=True
        )
        connected = conn.connect(host, 445, timeout=SMB_TIMEOUT)
        if not connected:
            result['smb_open'] = True
            result['error'] = 'Authentication failed'
            return result
        result['smb_open'] = True
        result['authenticated'] = True
        shares = conn.listShares(timeout=10)
        for share in shares:
            share_info = {
                'name': share.name,
                'type': share.type,
                'comments': share.comments or '',
                'readable': False,
                'file_count': 0
            }
            result['shares'].append(share_info)
        conn.close()
    except ConnectionRefusedError:
        result['error'] = 'Connection refused'
    except OSError:
        result['smb_open'] = False
        result['error'] = 'Host unreachable'
    except Exception as e:
        result['smb_open'] = True
        result['error'] = str(e)
    return result

def smb_enumerate_host_native(host):
    import ctypes
    import ctypes.wintypes
    result = {
        'host': host,
        'port': 445,
        'smb_open': False,
        'authenticated': False,
        'auth_user': os.environ.get('USERDOMAIN', '') + '\\' + os.environ.get('USERNAME', ''),
        'shares': [],
        'error': None
    }
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(SMB_TIMEOUT)
        s.connect((host, 445))
        s.close()
        result['smb_open'] = True
    except Exception:
        result['error'] = 'Port 445 closed'
        return result
    try:
        class SHARE_INFO_1(ctypes.Structure):
            _fields_ = [
                ('shi1_netname', ctypes.c_wchar_p),
                ('shi1_type', ctypes.c_uint32),
                ('shi1_remark', ctypes.c_wchar_p),
            ]
        netapi32 = ctypes.windll.netapi32
        buf = ctypes.c_void_p()
        entries_read = ctypes.c_uint32()
        total_entries = ctypes.c_uint32()
        resume_handle = ctypes.c_uint32(0)
        server = '\\\\' + host
        ret = netapi32.NetShareEnum(
            ctypes.c_wchar_p(server), 1,
            ctypes.byref(buf), 0xFFFFFFFF,
            ctypes.byref(entries_read),
            ctypes.byref(total_entries),
            ctypes.byref(resume_handle)
        )
        if ret == 0:
            result['authenticated'] = True
            arr_type = SHARE_INFO_1 * entries_read.value
            arr = ctypes.cast(buf, ctypes.POINTER(arr_type)).contents
            for share in arr:
                stype = share.shi1_type & 0xFF
                share_info = {
                    'name': share.shi1_netname or '',
                    'type': stype,
                    'comments': share.shi1_remark or '',
                    'readable': False,
                    'file_count': 0
                }
                result['shares'].append(share_info)
            netapi32.NetApiBufferFree(buf)
        elif ret == 5:
            result['error'] = 'Access denied'
        elif ret == 53:
            result['error'] = 'Bad network path'
        elif ret == 2222:
            result['error'] = 'Network timeout'
        else:
            result['error'] = 'NetShareEnum error ' + str(ret)
    except AttributeError:
        result['error'] = 'Not running on Windows'
    except Exception as e:
        result['error'] = str(e)
    return result

async def run_smb_scanning(hosts_with_smb, username, password, domain, output_dir, use_native=False):
    section('OPSEC — SMB ENUMERATION')
    if use_native:
        current_user = os.environ.get('USERDOMAIN', '') + '\\' + os.environ.get('USERNAME', '')
        print(f'{C.CYAN}[*]{C.RESET} Enumerating shares on {C.BOLD}{len(hosts_with_smb)}{C.RESET} hosts as {C.YELLOW}{current_user}{C.RESET} (native Windows API)')
    else:
        print(f'{C.CYAN}[*]{C.RESET} Enumerating shares on {C.BOLD}{len(hosts_with_smb)}{C.RESET} hosts as {C.YELLOW}{(domain + chr(92) + username) if domain else username}{C.RESET}')
    loop = asyncio.get_event_loop()
    semaphore = asyncio.Semaphore(10)
    async def bounded(host):
        async with semaphore:
            if use_native:
                return await loop.run_in_executor(None, smb_enumerate_host_native, host)
            else:
                return await loop.run_in_executor(None, smb_enumerate_host, host, username, password, domain)
    tasks = [bounded(h) for h in hosts_with_smb]
    results = await asyncio.gather(*tasks)
    results = list(results)
    for r in results:
        host = r['host']
        if r['authenticated']:
            disk_shares = [s for s in r['shares'] if s['type'] == 0]
            print(f'{C.GREEN}    [+]{C.RESET} {host} — {C.BOLD}{len(disk_shares)} disk shares{C.RESET}')
            for s in r['shares']:
                if s['type'] == 0:
                    comment = f' {C.GRAY}({s["comments"]}){C.RESET}' if s['comments'] else ''
                    print(f'{C.GREEN}        ● {s["name"]}{C.RESET}{comment}')
                elif s['type'] == 3:
                    print(f'{C.GRAY}        - {s["name"]:30s} (IPC){C.RESET}')
                elif s['type'] == 1:
                    print(f'{C.GRAY}        - {s["name"]:30s} (Printer){C.RESET}')
        elif r['smb_open']:
            print(f'{C.YELLOW}    [!]{C.RESET} {host} — SMB open, auth failed: {r.get("error", "unknown")}')
    authenticated = sum(1 for r in results if r['authenticated'])
    total_disk = sum(len([s for s in r['shares'] if s['type'] == 0]) for r in results if r['authenticated'])
    print(f'\n{C.GREEN}[+]{C.RESET} SMB: {C.BOLD}{authenticated}{C.RESET} authenticated, {C.BOLD}{total_disk}{C.RESET} disk shares found')
    return results

async def opsec_scan_hosts(hosts, db, username, password, domain, output_dir, max_threads=20, no_web=False, no_smb=False):
    import random
    OPSEC_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
    section('OPSEC — PORT DISCOVERY')
    all_ports = sorted(set(XLARGE_PORTS + SMB_PORTS))
    host_concurrency = min(max_threads, 5)
    port_concurrency = 20
    print(f'{C.CYAN}[*]{C.RESET} Scanning {C.BOLD}{len(hosts)}{C.RESET} hosts across {C.BOLD}{len(all_ports)}{C.RESET} ports (pure Python, no nmap)')
    print(f'{C.CYAN}[*]{C.RESET} Concurrency: {host_concurrency} hosts, {port_concurrency} ports/host')
    semaphore = asyncio.Semaphore(host_concurrency)
    host_ports = {}
    async def scan_one(host):
        async with semaphore:
            port_sem = asyncio.Semaphore(port_concurrency)
            async def check_port(port):
                async with port_sem:
                    try:
                        conn = asyncio.open_connection(host, port)
                        reader, writer = await asyncio.wait_for(conn, timeout=SCAN_TIMEOUT)
                        writer.close()
                        try:
                            await writer.wait_closed()
                        except Exception:
                            pass
                        return port
                    except Exception:
                        return None
            tasks = [check_port(p) for p in all_ports]
            results = await asyncio.gather(*tasks)
            await asyncio.sleep(random.uniform(0.3, 1.0))
            return (host, [p for p in results if p is not None])
    tasks = [scan_one(h) for h in hosts]
    results = await asyncio.gather(*tasks)
    for host, ports in results:
        if ports:
            host_ports[host] = ports
            web_p = [p for p in ports if p in XLARGE_PORTS]
            smb_p = [p for p in ports if p in SMB_PORTS]
            parts = []
            if web_p:
                parts.append(f'web:{",".join(str(p) for p in web_p[:5])}{"..." if len(web_p) > 5 else ""}')
            if smb_p:
                parts.append(f'smb:{",".join(str(p) for p in smb_p)}')
            print(f'{C.GREEN}    [+]{C.RESET} {host:18s} → {" | ".join(parts)}')
    hosts_with_web = {h: [p for p in ports if p in XLARGE_PORTS] for h, ports in host_ports.items() if any(p in XLARGE_PORTS for p in ports)}
    hosts_with_smb = [h for h, ports in host_ports.items() if 445 in ports]
    print(f'\n{C.GREEN}[+]{C.RESET} {C.BOLD}{len(host_ports)}{C.RESET} live hosts | {C.BOLD}{len(hosts_with_web)}{C.RESET} with web | {C.BOLD}{len(hosts_with_smb)}{C.RESET} with SMB')
    web_results = []
    if not no_web and hosts_with_web:
        section('OPSEC — WEB FINGERPRINTING')
        print(f'{C.CYAN}[*]{C.RESET} Fingerprinting {C.BOLD}{len(hosts_with_web)}{C.RESET} hosts (passive version detection, no endpoint probing)')
        ssl_ctx = ssl.create_default_context()
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = ssl.CERT_NONE
        connector = aiohttp.TCPConnector(ssl=ssl_ctx, limit=30)
        headers_ua = {'User-Agent': OPSEC_UA}
        async with aiohttp.ClientSession(connector=connector, headers=headers_ua) as session:
            fp_sem = asyncio.Semaphore(host_concurrency)
            async def fingerprint_opsec(host, ports):
                async with fp_sem:
                    services = []
                    for port in ports:
                        scheme = 'https' if port in HTTPS_PORTS else 'http'
                        url = normalize_url(scheme, host, port)
                        response = await fetch_url(session, f'{scheme}://{host}:{port}')
                        if not response:
                            alt = 'http' if scheme == 'https' else 'https'
                            response = await fetch_url(session, f'{alt}://{host}:{port}')
                            if response:
                                scheme = alt
                                url = normalize_url(scheme, host, port)
                        if not response:
                            continue
                        status = response.get('status')
                        if status and 400 <= status <= 499:
                            continue
                        title = extract_title(response.get('body', ''))
                        server = response.get('headers', {}).get('Server', response.get('headers', {}).get('server', 'Unknown'))
                        app_key, app_data = match_app(response, db)
                        version, vsource = detect_version_passive(response)
                        service = {'url': url, 'port': port, 'status': status, 'title': title, 'server': server, 'app_key': app_key, 'app_name': app_data['name'] if app_data else 'Unknown Application', 'version': version, 'version_source': vsource, 'credentials': app_data.get('default_credentials', []) if app_data else [], 'cves': app_data.get('cves', []) if app_data else [], 'screenshot': None}
                        if app_data:
                            vstr = f' {C.CYAN}v{version}{C.RESET}' if version else ''
                            print(f'{C.GREEN}    [+]{C.RESET} {url} \u2192 {C.YELLOW}{C.BOLD}{app_data["name"]}{C.RESET}{vstr}')
                            cve_ids = [c['id'] for c in app_data.get('cves', [])]
                            if cve_ids:
                                cve_str = ', '.join(cve_ids)
                                print(f'{C.RED}        CVEs: {cve_str}{C.RESET}')
                        else:
                            print(f'{C.GRAY}    [-]{C.RESET} {url} \u2192 Unknown (Title: {(title[:50] if title else "N/A")})')
                        services.append(service)
                        await asyncio.sleep(random.uniform(0.2, 0.5))
                    return {'host': host, 'open_ports': ports, 'services': services}
            tasks = [fingerprint_opsec(h, p) for h, p in hosts_with_web.items()]
            web_results = list(await asyncio.gather(*tasks))
    elif no_web:
        print(f'\n{C.YELLOW}[!]{C.RESET} Web fingerprinting skipped (--no-web)')
    smb_results = []
    if no_smb:
        print(f'\n{C.YELLOW}[!]{C.RESET} SMB enumeration skipped (--no-smb)')
    elif hosts_with_smb:
        has_explicit_creds = bool(username)
        if IS_WINDOWS and not has_explicit_creds:
            smb_results = await run_smb_scanning(hosts_with_smb, '', '', '', output_dir, use_native=True)
        elif has_explicit_creds and _smb_available:
            smb_results = await run_smb_scanning(hosts_with_smb, username, password, domain, output_dir, use_native=False)
        elif has_explicit_creds and not _smb_available:
            print(f'\n{C.YELLOW}[!]{C.RESET} pysmb not installed — cannot use explicit credentials')
            print(f'    Install: pip3 install pysmb')
            if IS_WINDOWS:
                print(f'{C.CYAN}[*]{C.RESET} Falling back to native Windows API (current user)')
                smb_results = await run_smb_scanning(hosts_with_smb, '', '', '', output_dir, use_native=True)
        elif not IS_WINDOWS and not has_explicit_creds:
            print(f'\n{C.YELLOW}[!]{C.RESET} No SMB credentials provided and not on Windows')
            print(f'    Use: --user USERNAME --password PASSWORD --smb-domain DOMAIN')
    return host_ports, web_results, smb_results

def save_smb_report(smb_results, output_dir):
    path = output_dir / 'smb_report.txt'
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(path, 'w') as f:
        f.write('=' * 70 + '\n')
        f.write('NetSeeker - SMB Enumeration Report\n')
        f.write('Generated: ' + ts + '\n')
        f.write('=' * 70 + '\n\n')
        authenticated = [r for r in smb_results if r['authenticated']]
        failed = [r for r in smb_results if r['smb_open'] and not r['authenticated']]
        f.write('AUTHENTICATED HOSTS (' + str(len(authenticated)) + ')\n')
        f.write('-' * 70 + '\n')
        for r in sorted(authenticated, key=lambda x: x['host']):
            f.write('\nHost:     ' + r['host'] + '\n')
            f.write('User:     ' + r['auth_user'] + '\n')
            disk_shares = [s for s in r['shares'] if s['type'] == 0]
            f.write('Shares:   ' + str(len(disk_shares)) + ' disk\n')
            for s in r['shares']:
                stype = {0: 'DISK', 1: 'PRINT', 2: 'DEVICE', 3: 'IPC'}.get(s['type'], 'OTHER')
                comment = (' (' + s['comments'] + ')') if s['comments'] else ''
                f.write('  ' + stype.ljust(8) + s['name'].ljust(32) + comment + '\n')
        if failed:
            f.write('\n\nAUTH FAILED (' + str(len(failed)) + ')\n')
            f.write('-' * 70 + '\n')
            for r in sorted(failed, key=lambda x: x['host']):
                f.write(r['host'] + '  — ' + (r.get('error') or 'unknown') + '\n')
    return path

def save_opsec_html_report(host_ports, web_results, smb_results, label, output_dir):
    h = _html.escape
    path = output_dir / 'netseeker_report.html'
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_hosts = len(host_ports)
    hosts_with_web = sum(1 for ports in host_ports.values() if any(p in XLARGE_PORTS for p in ports))
    hosts_with_smb = sum(1 for ports in host_ports.values() if 445 in ports)
    seen_urls = set()
    all_services = []
    for r in web_results:
        for svc in r.get("services", []):
            url = svc["url"]
            if url not in seen_urls:
                seen_urls.add(url)
                all_services.append(svc)
    groups = {}
    unknown = []
    for svc in all_services:
        if svc["app_key"]:
            app = svc["app_name"]
            groups.setdefault(app, []).append(svc)
        else:
            unknown.append(svc)
    ordered = []
    for app_name in sorted(groups.keys()):
        ordered.append((app_name, sorted(groups[app_name], key=lambda s: s["url"])))
    if unknown:
        ordered.append(("Unknown Application", sorted(unknown, key=lambda s: s["url"])))
    identified = sum(1 for s in all_services if s["app_key"])
    total_cves = sum(len(s["cves"]) for s in all_services)
    total_disk = sum(len([s for s in r['shares'] if s['type'] == 0]) for r in smb_results if r['authenticated'])
    body_html = ''
    for app_name, services in ordered:
        is_known = services[0]["app_key"] is not None
        header_color = '#60a5fa' if is_known else '#64748b'
        cards_html = ''
        for svc in services:
            url = svc["url"]
            title = h(svc["title"] or 'No Title')
            status = svc["status"] or 0
            shot = svc.get("screenshot")
            if status < 300:
                status_color = '#16a34a'
            elif status < 400:
                status_color = '#d97706'
            else:
                status_color = '#dc2626'
            if shot and Path(shot).exists():
                rel_shot = 'screenshots/' + Path(shot).name
                img_html = '<img src="' + h(rel_shot) + '" alt="' + title + '" loading="lazy">'
            else:
                img_html = '<div class="no-shot">No Screenshot</div>'
            cards_html += '\n            <div class="card"><a href="' + h(url) + '" target="_blank" rel="noopener"><div class="card-img">' + img_html + '</div><div class="card-info"><div class="card-url" title="' + h(url) + '">' + h(url) + '</div><div class="card-meta"><span class="status" style="background:' + status_color + '">' + str(status) + '</span></div><div class="card-title">' + title + '</div></div></a></div>'
        body_html += '\n        <div class="section"><div class="section-header" style="border-left:4px solid ' + header_color + '"><span class="section-title" style="color:' + header_color + '">' + h(app_name) + '</span><span class="section-count">' + str(len(services)) + ' service' + ("s" if len(services) != 1 else "") + '</span></div><div class="grid">' + cards_html + '</div></div>'
    smb_authenticated = [r for r in smb_results if r['authenticated']]
    if smb_authenticated:
        smb_cards = ''
        for r in sorted(smb_authenticated, key=lambda x: x['host']):
            disk_shares = [s for s in r['shares'] if s['type'] == 0]
            shares_html = ''
            for s in r['shares']:
                if s['type'] == 0:
                    comment = (' — ' + h(s['comments'])) if s['comments'] else ''
                    shares_html += '<div style="color:#a78bfa;font-size:11px;padding:2px 0">&#9632; ' + h(s["name"]) + '<span style="color:#64748b">' + comment + '</span></div>'
            smb_cards += '\n            <div class="card"><div class="card-info" style="padding:14px"><div class="card-url">' + h(r["host"]) + '</div><div style="font-size:10px;color:#64748b;margin:6px 0">User: ' + h(r["auth_user"]) + '</div><div style="font-size:11px;color:#94a3b8;margin-bottom:6px">' + str(len(disk_shares)) + ' disk shares</div>' + shares_html + '</div></div>'
        body_html += '\n        <div class="section"><div class="section-header" style="border-left:4px solid #a78bfa"><span class="section-title" style="color:#a78bfa">SMB Shares</span><span class="section-count">' + str(len(smb_authenticated)) + ' host' + ("s" if len(smb_authenticated) != 1 else "") + '</span></div><div class="grid">' + smb_cards + '</div></div>'
    if not body_html:
        body_html = '<p class="empty">No services found.</p>'
    css = "*{box-sizing:border-box;margin:0;padding:0} body{font-family:'Segoe UI',system-ui,sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh} header{background:#1e293b;padding:20px 30px;border-bottom:1px solid #334155;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px} header h1{font-size:22px;color:#60a5fa;font-weight:700;letter-spacing:1px} header p{font-size:12px;color:#64748b} .stats{display:flex;gap:12px;flex-wrap:wrap} .stat{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:8px 16px;text-align:center} .stat .num{font-size:22px;font-weight:bold;color:#60a5fa} .stat .lbl{font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:1px} .section{padding:20px 30px 0} .section-header{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#1e293b;border-radius:8px;margin-bottom:14px} .section-title{font-size:14px;font-weight:700;letter-spacing:0.5px} .section-count{font-size:11px;color:#64748b;background:#0f172a;padding:3px 10px;border-radius:12px} .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;margin-bottom:20px} .card{background:#1e293b;border:1px solid #334155;border-radius:10px;overflow:hidden;transition:transform .15s,border-color .15s} .card:hover{transform:translateY(-3px);border-color:#3b82f6} .card a{text-decoration:none;color:inherit;display:block} .card-img{width:100%;height:175px;background:#0f172a;overflow:hidden;display:flex;align-items:center;justify-content:center} .card-img img{width:100%;height:100%;object-fit:cover;object-position:top} .no-shot{color:#475569;font-size:12px} .card-info{padding:10px 12px} .card-url{font-size:11px;color:#60a5fa;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:6px} .card-meta{display:flex;gap:6px;align-items:center;margin-bottom:4px} .status{font-size:10px;font-weight:700;color:#fff;padding:2px 7px;border-radius:4px} .card-title{font-size:11px;color:#94a3b8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .empty{color:#475569;padding:40px;text-align:center} footer{text-align:center;padding:20px;color:#475569;font-size:11px;border-top:1px solid #1e293b;margin-top:20px}"
    html_content = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>NetSeeker OPSEC - " + h(label) + "</title><style>" + css + "</style></head><body><header><div><h1>&#128373; NETSEEKER OPSEC</h1><p>Target: " + h(label) + " &nbsp;|&nbsp; " + ts + "</p></div><div class='stats'><div class='stat'><div class='num'>" + str(total_hosts) + "</div><div class='lbl'>Live Hosts</div></div><div class='stat'><div class='num'>" + str(identified) + "</div><div class='lbl'>Apps ID</div></div><div class='stat'><div class='num'>" + str(total_cves) + "</div><div class='lbl'>CVEs</div></div><div class='stat'><div class='num'>" + str(total_disk) + "</div><div class='lbl'>SMB Shares</div></div></div></header>" + body_html + "<footer>NetSeeker OPSEC &nbsp;|&nbsp; For authorized penetration testing only</footer></body></html>"
    with open(path, 'w') as f:
        f.write(html_content)
    return path

def save_resolved_hosts(resolved, output_dir):
    path = output_dir / 'resolved_hosts.txt'
    with open(path, 'w') as f:
        f.write(f'# NetSeeker — Resolved Hosts\n')
        f.write(f'# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
        f.write(f'# Total: {len(resolved)}\n\n')
        for r in resolved:
            hostname = r.get('hostname', r.get('ip', ''))
            ip = r.get('ip', '')
            f.write(f'{ip:20s} {hostname}\n')
    return path

def save_live_subnets(subnet_results, output_dir):
    path = output_dir / 'live_subnets.txt'
    subnets = sorted(subnet_results.keys())
    with open(path, 'w') as f:
        f.write(f'# NetSeeker — Live Subnets\n')
        f.write(f'# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
        f.write(f'# Total: {len(subnets)}\n\n')
        for subnet in subnets:
            hosts = subnet_results[subnet]
            f.write(f'{subnet:20s} ({len(hosts)} live)\n')
    return path

def save_live_hosts(live_hosts, output_dir):
    path = output_dir / 'live_hosts.txt'
    sorted_hosts = sorted(live_hosts, key=lambda x: ipaddress.IPv4Address(x))
    with open(path, 'w') as f:
        f.write(f'# NetSeeker — Live Hosts\n')
        f.write(f'# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
        f.write(f'# Total: {len(sorted_hosts)}\n\n')
        for ip in sorted_hosts:
            f.write(f'{ip}\n')
    return path

def save_txt_report(web_results, output_dir):
    path = output_dir / 'web_report.txt'
    with open(path, 'w') as f:
        f.write('=' * 70 + '\n')
        f.write('NetSeeker - Web Fingerprinting Report\n')
        f.write(f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
        f.write('=' * 70 + '\n\n')
        identified = [s for r in web_results for s in r.get('services', []) if s['app_key']]
        unknown = [s for r in web_results for s in r.get('services', []) if not s['app_key']]
        f.write(f'IDENTIFIED APPLICATIONS ({len(identified)})\n')
        f.write('-' * 70 + '\n')
        for svc in identified:
            f.write(f'\nURL:         {svc["url"]}\n')
            f.write(f'Application: {svc["app_name"]}\n')
            f.write(f'Version:     {svc.get("version") or "Not detected"}')
            if svc.get('version_source'):
                f.write(f' (from {svc["version_source"]})')
            f.write('\n')
            f.write(f'Title:       {svc["title"]}\n')
            f.write(f'Server:      {svc["server"]}\n')
            if svc['credentials']:
                f.write('Default Credentials:\n')
                for cred in svc['credentials']:
                    f.write(f'  - {cred["username"]} / {cred["password"] or "(empty)"}\n')
            if svc['cves']:
                f.write('CVEs:\n')
                for cve in svc['cves']:
                    f.write(f'  - {cve["id"]} (CVSS: {cve["cvss"]}) {cve["description"]}\n')
            f.write('\n')
        f.write(f'\nUNKNOWN APPLICATIONS ({len(unknown)})\n')
        f.write('-' * 70 + '\n')
        for svc in unknown:
            f.write(f'\nURL:    {svc["url"]}\n')
            f.write(f'Title:  {svc["title"]}\n')
            f.write(f'Server: {svc["server"]}\n')
            if svc.get('version'):
                f.write(f'Version: {svc["version"]}\n')
            f.write('Action: Manual investigation required\n')
    return path

def save_html_report(dcs, live_hosts, subnet_results, web_results, domain, output_dir):
    h = _html.escape
    path = output_dir / 'netseeker_report.html'
    seen_urls = set()
    all_services = []
    for r in web_results:
        for svc in r.get('services', []):
            url = svc['url']
            if url not in seen_urls:
                seen_urls.add(url)
                all_services.append(svc)
    groups = {}
    unknown = []
    for svc in all_services:
        if svc['app_key']:
            app = svc['app_name']
            groups.setdefault(app, []).append(svc)
        else:
            unknown.append(svc)
    ordered = []
    for app_name in sorted(groups.keys()):
        ordered.append((app_name, sorted(groups[app_name], key=lambda s: s['url'])))
    if unknown:
        ordered.append(('Unknown Application', sorted(unknown, key=lambda s: s['url'])))
    total_live = len(live_hosts)
    total_services = len(all_services)
    identified = sum((1 for s in all_services if s['app_key']))
    total_cves = sum((len(s['cves']) for s in all_services))
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    body_html = ''
    for app_name, services in ordered:
        is_known = services[0]['app_key'] is not None
        section_color = '#1e3a5f' if is_known else '#1e293b'
        header_color = '#60a5fa' if is_known else '#64748b'
        cards_html = ''
        for svc in services:
            url = svc['url']
            title = h(svc['title'] or 'No Title')
            status = svc['status'] or 0
            shot = svc.get('screenshot')
            if status < 300:
                status_color = '#16a34a'
            elif status < 400:
                status_color = '#d97706'
            else:
                status_color = '#dc2626'
            if shot and Path(shot).exists():
                rel_shot = f'screenshots/{Path(shot).name}'
                img_html = f'<img src="{h(rel_shot)}" alt="{title}" loading="lazy">'
            else:
                img_html = '<div class="no-shot">No Screenshot</div>'
            cards_html += f'\n            <div class="card">\n                <a href="{h(url)}" target="_blank" rel="noopener">\n                    <div class="card-img">{img_html}</div>\n                    <div class="card-info">\n                        <div class="card-url" title="{h(url)}">{h(url)}</div>\n                        <div class="card-meta">\n                            <span class="status" style="background:{status_color}">{status}</span>\n                        </div>\n                        <div class="card-title">{title}</div>\n                    </div>\n                </a>\n            </div>'
        body_html += f'\n        <div class="section">\n            <div class="section-header" style="border-left:4px solid {header_color}">\n                <span class="section-title" style="color:{header_color}">{h(app_name)}</span>\n                <span class="section-count">{len(services)} service{("s" if len(services) != 1 else "")}</span>\n            </div>\n            <div class="grid">{cards_html}</div>\n        </div>'
    if not body_html:
        body_html = '<p class="empty">No web services found.</p>'
    css = "*{box-sizing:border-box;margin:0;padding:0} body{font-family:'Segoe UI',system-ui,sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh} header{background:#1e293b;padding:20px 30px;border-bottom:1px solid #334155;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px} header h1{font-size:22px;color:#60a5fa;font-weight:700;letter-spacing:1px} header p{font-size:12px;color:#64748b} .stats{display:flex;gap:12px;flex-wrap:wrap} .stat{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:8px 16px;text-align:center} .stat .num{font-size:22px;font-weight:bold;color:#60a5fa} .stat .lbl{font-size:10px;color:#64748b;text-transform:uppercase;letter-spacing:1px} .section{padding:20px 30px 0} .section-header{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#1e293b;border-radius:8px;margin-bottom:14px} .section-title{font-size:14px;font-weight:700;letter-spacing:0.5px} .section-count{font-size:11px;color:#64748b;background:#0f172a;padding:3px 10px;border-radius:12px} .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;margin-bottom:20px} .card{background:#1e293b;border:1px solid #334155;border-radius:10px;overflow:hidden;transition:transform .15s,border-color .15s} .card:hover{transform:translateY(-3px);border-color:#3b82f6} .card a{text-decoration:none;color:inherit;display:block} .card-img{width:100%;height:175px;background:#0f172a;overflow:hidden;display:flex;align-items:center;justify-content:center} .card-img img{width:100%;height:100%;object-fit:cover;object-position:top} .no-shot{color:#475569;font-size:12px} .card-info{padding:10px 12px} .card-url{font-size:11px;color:#60a5fa;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:6px} .card-meta{display:flex;gap:6px;align-items:center;margin-bottom:4px} .status{font-size:10px;font-weight:700;color:#fff;padding:2px 7px;border-radius:4px} .card-title{font-size:11px;color:#94a3b8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis} .empty{color:#475569;padding:40px;text-align:center} footer{text-align:center;padding:20px;color:#475569;font-size:11px;border-top:1px solid #1e293b;margin-top:20px}"
    html = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>NetSeeker - " + h(domain) + '</title><style>' + css + '</style></head><body><header><div><h1>&#9889; NETSEEKER</h1><p>Domain: ' + h(domain) + ' &nbsp;|&nbsp; ' + ts + "</p></div><div class='stats'><div class='stat'><div class='num'>" + str(total_live) + "</div><div class='lbl'>Live Hosts</div></div><div class='stat'><div class='num'>" + str(total_services) + "</div><div class='lbl'>Web Services</div></div><div class='stat'><div class='num'>" + str(identified) + "</div><div class='lbl'>Identified</div></div><div class='stat'><div class='num'>" + str(total_cves) + "</div><div class='lbl'>CVEs</div></div></div></header>" + body_html + '<footer>NetSeeker &nbsp;|&nbsp; For authorized penetration testing only</footer></body></html>'
    with open(path, 'w') as f:
        f.write(html)
    return path

async def main():
    banner()
    parser = argparse.ArgumentParser(description='NetSeeker - DC Discovery, Network Mapping & Web Fingerprinting', formatter_class=argparse.RawTextHelpFormatter, epilog='\nExamples:\n  # Full run — DC discovery + network mapping + web fingerprinting\n  sudo python3 netseeker.py corp.local\n\n  # Skip web fingerprinting\n  sudo python3 netseeker.py corp.local --no-web\n\n  # Web fingerprinting only from a hosts file (skip Phases 1 & 2)\n  sudo python3 netseeker.py --hosts hosts.txt\n\nOPSEC MODE (no nmap, no root, EDR-safe):\n  # Web + SMB recon using current Windows user (no creds needed)\n  python netseeker.py --opsec --hosts targets.txt\n\n  # From AD computer names (current Windows user)\n  python netseeker.py --opsec --computers comp.txt --domain corp.local\n\n  # With explicit creds (different user or from Linux)\n  python netseeker.py --opsec --hosts targets.txt --user svc_backup --smb-domain CORP\n\n  # Web only, skip SMB\n  python netseeker.py --opsec --hosts targets.txt --no-smb\n\n  # SMB only, skip web\n  python netseeker.py --opsec --hosts targets.txt --no-web\n')
    parser.add_argument('domain', nargs='?', default=None, help='Target domain for DC discovery (e.g. corp.local)')
    parser.add_argument('--domain', dest='domain_flag', metavar='DOMAIN', default=None, help='Target domain (alternative to positional argument)')
    parser.add_argument('--hosts', metavar='FILE', help='File with IPs to scan (one per line) — skips Phases 1 & 2')
    parser.add_argument('--computers', metavar='FILE', help='File with computer names (one per line) — resolves to IPs then scans subnets')
    parser.add_argument('-o', '--output', default=str(OUTPUT_DIR), help='Output directory')
    parser.add_argument('--no-web', action='store_true', help='Skip web fingerprinting')
    parser.add_argument('--no-smb', action='store_true', help='Skip SMB enumeration (opsec mode)')
    parser.add_argument('--threads', type=int, default=20, help='Max concurrent web scan threads (default: 20)')
    parser.add_argument('--batch-size', type=int, default=100, help='DNS resolution batch size (default: 100)')
    parser.add_argument('--batch-delay', type=float, default=0.2, help='Delay between DNS batches in seconds (default: 0.2)')
    parser.add_argument('--opsec', action='store_true', help='OPSEC mode: no nmap, no root, pure Python + SMB')
    parser.add_argument('--user', default='', help='SMB username (omit on Windows to use current user)')
    parser.add_argument('--password', default='', help='SMB password (omit to be prompted securely)')
    parser.add_argument('--smb-domain', default='', help='SMB/AD domain for authentication')
    args = parser.parse_args()
    if args.domain_flag:
        args.domain = args.domain_flag
    if args.user and not args.password:
        import getpass
        args.password = getpass.getpass(f'Password for {args.user}: ')
    if not args.domain and (not args.hosts) and (not args.computers):
        parser.print_help()
        print(f'\n{C.RED}[!] Error: provide a domain, --hosts, or --computers file.{C.RESET}')
        print(f'    Example: sudo python3 netseeker.py corp.local')
        print(f'    Example: sudo python3 netseeker.py --hosts hosts.txt')
        print(f'    Example: sudo python3 netseeker.py --computers computers.txt --domain corp.local')
        sys.exit(1)
    if args.computers and (not args.domain):
        print(f'{C.RED}[!] --computers requires --domain to append to hostnames.{C.RESET}')
        print(f'    Example: sudo python3 netseeker.py --computers computers.txt --domain corp.local')
        sys.exit(1)
    if args.hosts and (not Path(args.hosts).exists()):
        print(f'{C.RED}[!] Hosts file not found: {args.hosts}{C.RESET}')
        sys.exit(1)
    if args.computers and (not Path(args.computers).exists()):
        print(f'{C.RED}[!] Computers file not found: {args.computers}{C.RESET}')
        sys.exit(1)
    if args.opsec:
        if not args.hosts and not args.computers:
            print(f'{C.RED}[!] --opsec requires --hosts or --computers (no nmap subnet sweep in opsec mode){C.RESET}')
            print(f'    Example: python netseeker.py --opsec --hosts targets.txt')
            print(f'    Example: python netseeker.py --opsec --computers comp.txt --domain corp.local')
            sys.exit(1)
        label = args.domain.strip().lower() if args.domain else Path(args.computers).stem if args.computers else Path(args.hosts).stem
        output_dir = Path(args.output) / f'{label}_opsec_{datetime.now().strftime("%Y%m%d_%H%M%S")}'
        output_dir.mkdir(parents=True, exist_ok=True)
        db = load_database()
        start = datetime.now()
        auth_info = ''
        if args.user:
            auth_info = f' | Auth: {C.YELLOW}{args.smb_domain + chr(92) + args.user if args.smb_domain else args.user}{C.RESET}'
        elif IS_WINDOWS:
            auth_info = f' | Auth: {C.YELLOW}{os.environ.get("USERDOMAIN", "")}{chr(92)}{os.environ.get("USERNAME", "")}{C.RESET} (current user)'
        print(f'{C.CYAN}[*]{C.RESET} Mode: {C.BOLD}{C.PURPLE}OPSEC{C.RESET} (no nmap, no root, pure Python){auth_info}')
        print(f'{C.CYAN}[*]{C.RESET} Output directory: {C.BOLD}{output_dir}{C.RESET}')
        target_ips = []
        if args.hosts:
            with open(args.hosts) as f:
                raw = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            for h in raw:
                try:
                    ipaddress.IPv4Address(h)
                    target_ips.append(h)
                except ValueError:
                    print(f'{C.YELLOW}    [!]{C.RESET} Skipping invalid IP: {h}')
        elif args.computers:
            domain = args.domain.strip().lower()
            resolved = await resolve_computers(args.computers, domain, batch_size=args.batch_size, batch_delay=args.batch_delay)
            if not resolved:
                print(f'{C.RED}[!] No computer names resolved.{C.RESET}')
                return
            save_resolved_hosts(resolved, output_dir)
            target_ips = [r["ip"] for r in resolved]
        if not target_ips:
            print(f'{C.RED}[!] No target IPs to scan.{C.RESET}')
            sys.exit(1)
        print(f'{C.CYAN}[*]{C.RESET} Targets: {C.BOLD}{len(target_ips)}{C.RESET} IPs')
        host_ports, web_results, smb_results = await opsec_scan_hosts(
            target_ips, db, args.user, args.password, args.smb_domain,
            output_dir, max_threads=args.threads, no_web=args.no_web, no_smb=args.no_smb
        )
        section('REPORTS')
        txt_path = save_txt_report(web_results, output_dir)
        print(f'{C.GREEN}[+]{C.RESET} Web Report:   {C.BOLD}{txt_path}{C.RESET}')
        if smb_results:
            smb_path = save_smb_report(smb_results, output_dir)
            print(f'{C.GREEN}[+]{C.RESET} SMB Report:   {C.BOLD}{smb_path}{C.RESET}')
        html_path = save_opsec_html_report(host_ports, web_results, smb_results, label, output_dir)
        print(f'{C.GREEN}[+]{C.RESET} HTML Report:  {C.BOLD}{html_path}{C.RESET}')
        live_hosts_path = output_dir / 'live_hosts.txt'
        with open(live_hosts_path, 'w') as f:
            for ip in sorted(host_ports.keys(), key=lambda x: ipaddress.IPv4Address(x)):
                f.write(ip + '\n')
        print(f'{C.GREEN}[+]{C.RESET} Live Hosts:   {C.BOLD}{live_hosts_path}{C.RESET}')
        elapsed = (datetime.now() - start).total_seconds()
        identified = sum(1 for r in web_results for s in r.get("services", []) if s["app_key"])
        total_cves = sum(len(s["cves"]) for r in web_results for s in r.get("services", []))
        total_disk = sum(len([s for s in r['shares'] if s['type'] == 0]) for r in smb_results if r['authenticated'])
        sep55 = '─' * 55
        print(f'\n{C.BOLD}{sep55}{C.RESET}')
        print(f'  {C.PURPLE}OPSEC MODE{C.RESET}')
        print(f'  Targets Scanned:       {len(target_ips)}')
        print(f'  Live Hosts:            {len(host_ports)}')
        print(f'  Web Services:          {sum(len(r.get("services", [])) for r in web_results)}')
        print(f'  Apps Identified:       {identified}')
        print(f'  CVEs Flagged:          {total_cves}')
        print(f'  SMB Hosts:             {sum(1 for r in smb_results if r["authenticated"])}')
        print(f'  Disk Shares:           {total_disk}')
        print(f'  Total Time:            {elapsed:.1f}s')
        sep55 = '─' * 55
        print(f'{C.BOLD}{sep55}{C.RESET}\n')
        return
    check_root()
    check_dependencies()
    label = args.domain.strip().lower() if args.domain else Path(args.computers).stem if args.computers else Path(args.hosts).stem
    output_dir = Path(args.output) / f'{label}_{datetime.now().strftime("%Y%m%d_%H%M%S")}'
    output_dir.mkdir(parents=True, exist_ok=True)
    db = load_database()
    start = datetime.now()
    print(f'{C.CYAN}[*]{C.RESET} Output directory: {C.BOLD}{output_dir}{C.RESET}')
    if args.hosts:
        section('HOSTS FILE MODE — WEB FINGERPRINTING ONLY')
        with open(args.hosts) as f:
            live_hosts = [line.strip() for line in f if line.strip() and (not line.startswith('#'))]
        valid_hosts = []
        for h in live_hosts:
            try:
                ipaddress.IPv4Address(h)
                valid_hosts.append(h)
            except ValueError:
                print(f'{C.YELLOW}    [!]{C.RESET} Skipping invalid IP: {h}')
        live_hosts = valid_hosts
        if not live_hosts:
            print(f'{C.RED}[!] No valid IPs found in {args.hosts}{C.RESET}')
            sys.exit(1)
        print(f'{C.CYAN}[*]{C.RESET} Loaded {C.BOLD}{len(live_hosts)}{C.RESET} hosts from {args.hosts}')
        subnet_results = {'(from hosts file)': live_hosts}
        live_hosts_path = save_live_hosts(live_hosts, output_dir)
        live_subnets_path = save_live_subnets(subnet_results, output_dir)
        web_results = []
        if not args.no_web:
            web_results = await run_web_fingerprinting(live_hosts, db, output_dir, max_threads=args.threads)
        else:
            print(f'\n{C.YELLOW}[!]{C.RESET} Web fingerprinting skipped (--no-web)')
        section('REPORTS')
        txt_path = save_txt_report(web_results, output_dir)
        html_path = save_html_report([], live_hosts, subnet_results, web_results, label, output_dir)
        elapsed = (datetime.now() - start).total_seconds()
        print(f'{C.GREEN}[+]{C.RESET} Live Hosts:    {C.BOLD}{live_hosts_path}{C.RESET}')
        print(f'{C.GREEN}[+]{C.RESET} Live Subnets:  {C.BOLD}{live_subnets_path}{C.RESET}')
        print(f'{C.GREEN}[+]{C.RESET} TXT Report:    {C.BOLD}{txt_path}{C.RESET}')
        print(f'{C.GREEN}[+]{C.RESET} HTML Report:   {C.BOLD}{html_path}{C.RESET}')
        identified = sum((1 for r in web_results for s in r.get('services', []) if s['app_key']))
        total_cves = sum((len(s['cves']) for r in web_results for s in r.get('services', [])))
        sep55 = '─' * 55
        print(f'\n{C.BOLD}{sep55}{C.RESET}')
        print(f'  Hosts Scanned:         {len(live_hosts)}')
        print(f'  Web Services Found:    {sum((len(r.get("services", [])) for r in web_results))}')
        print(f'  Apps Identified:       {identified}')
        print(f'  CVEs Flagged:          {total_cves}')
        print(f'  Total Time:            {elapsed:.1f}s')
        sep55 = '─' * 55
        print(f'{C.BOLD}{sep55}{C.RESET}\n')
        return
    if args.computers:
        domain = args.domain.strip().lower()
        print(f'{C.CYAN}[*]{C.RESET} Mode: Computer Names Resolution')
        print(f'{C.CYAN}[*]{C.RESET} Domain: {C.BOLD}{domain}{C.RESET}')
        resolved = await resolve_computers(args.computers, domain, batch_size=args.batch_size, batch_delay=args.batch_delay)
        if not resolved:
            print(f'{C.RED}[!] No computer names resolved. Check domain and DNS.{C.RESET}')
            return
        resolved_path = save_resolved_hosts(resolved, output_dir)
        subnets = get_unique_subnets(resolved)
        print(f'{C.CYAN}[*]{C.RESET} Unique /24 subnets: {C.BOLD}{len(subnets)}{C.RESET}')
        for subnet in sorted(subnets.keys()):
            print(f'    {subnet}')
        live_hosts, subnet_results = await scan_all_subnets(list(subnets.keys()))
        live_hosts_path = save_live_hosts(live_hosts, output_dir)
        live_subnets_path = save_live_subnets(subnet_results, output_dir)
        print(f'\n{C.GREEN}[+]{C.RESET} Live hosts saved: {live_hosts_path}')
        if not live_hosts:
            print(f'{C.YELLOW}[!]{C.RESET} No live hosts found.')
            return
        web_results = []
        if not args.no_web:
            web_results = await run_web_fingerprinting(live_hosts, db, output_dir, max_threads=args.threads)
        else:
            print(f'\n{C.YELLOW}[!]{C.RESET} Web fingerprinting skipped (--no-web)')
        section('REPORTS')
        txt_path = save_txt_report(web_results, output_dir)
        html_path = save_html_report(resolved, live_hosts, subnet_results, web_results, domain, output_dir)
        elapsed = (datetime.now() - start).total_seconds()
        print(f'{C.GREEN}[+]{C.RESET} Resolved Hosts: {C.BOLD}{resolved_path}{C.RESET}')
        print(f'{C.GREEN}[+]{C.RESET} Live Hosts:     {C.BOLD}{live_hosts_path}{C.RESET}')
        print(f'{C.GREEN}[+]{C.RESET} Live Subnets:   {C.BOLD}{live_subnets_path}{C.RESET}')
        print(f'{C.GREEN}[+]{C.RESET} TXT Report:    {C.BOLD}{txt_path}{C.RESET}')
        print(f'{C.GREEN}[+]{C.RESET} HTML Report:   {C.BOLD}{html_path}{C.RESET}')
        identified = sum((1 for r in web_results for s in r.get('services', []) if s['app_key']))
        total_cves = sum((len(s['cves']) for r in web_results for s in r.get('services', [])))
        sep55 = '─' * 55
        print(f'\n{C.BOLD}{sep55}{C.RESET}')
        print(f'  Computer Names:        {sum((1 for l in open(args.computers) if l.strip()))}')
        print(f'  Resolved:              {len(resolved)}')
        print(f'  Unique Subnets:        {len(subnets)}')
        print(f'  Live Hosts:            {len(live_hosts)}')
        print(f'  Web Services Found:    {sum((len(r.get("services", [])) for r in web_results))}')
        print(f'  Apps Identified:       {identified}')
        print(f'  CVEs Flagged:          {total_cves}')
        print(f'  Total Time:            {elapsed:.1f}s')
        sep55 = '─' * 55
        print(f'{C.BOLD}{sep55}{C.RESET}\n')
        return
    domain = args.domain.strip().lower()
    print(f'{C.CYAN}[*]{C.RESET} Target domain:    {C.BOLD}{domain}{C.RESET}')
    dcs = discover_dcs(domain)
    resolved_path = save_resolved_hosts(dcs, output_dir)
    print(f'\n{C.GREEN}[+]{C.RESET} Resolved hosts saved: {resolved_path}')
    subnets = get_unique_subnets(dcs)
    print(f'{C.CYAN}[*]{C.RESET} Unique /24 subnets to scan: {C.BOLD}{len(subnets)}{C.RESET}')
    for subnet, subnet_dcs in subnets.items():
        dc_names = ', '.join((d['hostname'] for d in subnet_dcs))
        print(f'    {subnet} (DC: {dc_names})')
    live_hosts, subnet_results = await scan_all_subnets(list(subnets.keys()))
    live_hosts_path = save_live_hosts(live_hosts, output_dir)
    live_subnets_path = save_live_subnets(subnet_results, output_dir)
    print(f'\n{C.GREEN}[+]{C.RESET} Live hosts saved: {live_hosts_path}')
    if not live_hosts:
        print(f'{C.YELLOW}[!]{C.RESET} No live hosts found. Exiting.')
        return
    web_results = []
    if not args.no_web:
        web_results = await run_web_fingerprinting(live_hosts, db, output_dir, max_threads=args.threads)
    else:
        print(f'\n{C.YELLOW}[!]{C.RESET} Web fingerprinting skipped (--no-web)')
    section('REPORTS')
    txt_path = save_txt_report(web_results, output_dir)
    html_path = save_html_report(dcs, live_hosts, subnet_results, web_results, domain, output_dir)
    elapsed = (datetime.now() - start).total_seconds()
    print(f'{C.GREEN}[+]{C.RESET} Resolved Hosts: {C.BOLD}{resolved_path}{C.RESET}')
    print(f'{C.GREEN}[+]{C.RESET} Live Hosts:     {C.BOLD}{live_hosts_path}{C.RESET}')
    print(f'{C.GREEN}[+]{C.RESET} Live Subnets:   {C.BOLD}{live_subnets_path}{C.RESET}')
    print(f'{C.GREEN}[+]{C.RESET} TXT Report:   {C.BOLD}{txt_path}{C.RESET}')
    print(f'{C.GREEN}[+]{C.RESET} HTML Report:  {C.BOLD}{html_path}{C.RESET}')
    identified = sum((1 for r in web_results for s in r.get('services', []) if s['app_key']))
    total_cves = sum((len(s['cves']) for r in web_results for s in r.get('services', [])))
    sep55 = '─' * 55
    print(f'\n{C.BOLD}{sep55}{C.RESET}')
    print(f'  Domain Controllers:    {len(dcs)}')
    print(f'  Unique Subnets:        {len(subnets)}')
    print(f'  Live Hosts:            {len(live_hosts)}')
    print(f'  Web Services Found:    {sum((len(r.get("services", [])) for r in web_results))}')
    print(f'  Apps Identified:       {identified}')
    print(f'  CVEs Flagged:          {total_cves}')
    print(f'  Total Time:            {elapsed:.1f}s')
    sep55 = '─' * 55
    print(f'{C.BOLD}{sep55}{C.RESET}\n')
if __name__ == '__main__':
    asyncio.run(main())