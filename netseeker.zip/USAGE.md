# NetSeeker — Usage Guide

## Overview
NetSeeker is a professional penetration testing tool that automates:
1. Target discovery (via domain, computer names, or IP list)
2. Network mapping of discovered subnets
3. Web service fingerprinting with default credentials and CVE lookup
4. Screenshots of all live web services

Must be run as root.

---

## Installation

```bash
sudo bash install.sh
```

---

## Modes

### Mode A — Domain Discovery
Discovers Domain Controllers via DNS SRV records, maps subnets, fingerprints.

```bash
sudo python3 netseeker.py corp.local
sudo python3 netseeker.py corp.local --no-web
sudo python3 netseeker.py corp.local -o /opt/engagements/client1/
```

### Mode B — Computer Names
Resolves AD computer names to IPs, extracts subnets, scans and fingerprints.

```bash
sudo python3 netseeker.py --computers computers.txt --domain corp.local
sudo python3 netseeker.py --computers computers.txt --domain corp.local --batch-size 200
sudo python3 netseeker.py --computers computers.txt --domain corp.local --no-web
```

Computer names file — one name per line, no domain suffix:
```
SERVERWEB01
DC01
FILESERVER02
```

### Mode C — IP List
Takes IPs directly, skips discovery and network mapping.

```bash
sudo python3 netseeker.py --hosts hosts.txt
sudo python3 netseeker.py --hosts hosts.txt --threads 30
```

### Mode D — OPSEC (Red Team)
No nmap, no root, pure Python port scanning + SMB share enumeration.
Safe for use on domain-joined machines with EDR.

```bash
# Web + SMB using current Windows user (no password needed)
python netseeker.py --opsec --hosts targets.txt

# From computer names (current Windows user)
python netseeker.py --opsec --computers comp.txt --domain corp.local

# With explicit creds (different user or from Linux)
python netseeker.py --opsec --hosts targets.txt --user svc_backup --smb-domain CORP
# (password will be prompted securely — never on command line)

# Web only, skip SMB
python netseeker.py --opsec --hosts targets.txt --no-smb

# SMB only, skip web
python netseeker.py --opsec --hosts targets.txt --no-web
```

On Windows: uses native `netapi32.dll` API with current user's Kerberos/NTLM session — zero credentials on disk or command line.

On Linux: requires `--user` + `--smb-domain`. Password prompted via `getpass` if omitted.

Optional: `pip install pysmb` (only needed when using explicit `--user` credentials).

---

## All Options

| Flag | Description | Default |
|------|-------------|---------|
| `domain` | Target domain for DC discovery | — |
| `--computers FILE` | Computer names file (requires --domain) | — |
| `--hosts FILE` | IP list — skips phases 1 and 2 | — |
| `--domain DOMAIN` | Domain suffix for --computers mode | — |
| `-o, --output DIR` | Output directory | ./output/ |
| `--no-web` | Skip web fingerprinting | off |
| `--no-smb` | Skip SMB enumeration (opsec mode) | off |
| `--threads N` | Concurrent web scan threads | 20 |
| `--batch-size N` | DNS resolution batch size | 100 |
| `--batch-delay N` | Delay between DNS batches in seconds | 0.2 |
| `--opsec` | OPSEC mode: no nmap, no root, pure Python + SMB | off |
| `--user USER` | SMB username (omit on Windows to use current user) | — |
| `--password PW` | SMB password (omit to be prompted securely) | — |
| `--smb-domain DOMAIN` | SMB/AD domain for authentication | — |

---

## Output Files

Each run creates: `output/<label>_YYYYMMDD_HHMMSS/`

| File | Description |
|------|-------------|
| `resolved_hosts.txt` | IPs from DC discovery or computer name resolution (IP + hostname) |
| `live_subnets.txt` | Unique /24 subnets scanned with live host count |
| `live_hosts.txt` | All IPs that responded — one per line, sorted |
| `web_report.txt` | Identified apps, versions, credentials, CVEs |
| `smb_report.txt` | SMB shares per host with access status (opsec mode only) |
| `netseeker_report.html` | Visual report with screenshots grouped by application |
| `screenshots/` | PNG screenshots of each live web service |

### resolved_hosts.txt
```
10.21.12.5           dc01.corp.local
10.21.12.8           dc02.corp.local
```

### live_subnets.txt
```
10.21.12.0/24        (47 live)
10.21.14.0/24        (23 live)
```

### live_hosts.txt
```
10.21.12.1
10.21.12.5
10.21.12.8
```

---

## Network Discovery

Uses nmap with all techniques:
- ICMP echo, timestamp, netmask
- TCP SYN ping: 22,80,443,445,3389,8080,8443,8888,3306
- TCP ACK ping: 80,443,8080
- UDP ping
- Max 5 concurrent subnet scans, 300s timeout per subnet

---

## Database

30 applications: Cisco IOS XE, HP iLO 4, ZKTeco BioTime, Qlik Sense,
F5 BIG-IP, Palo Alto, VMware vCenter, Fortinet, GitLab, Jenkins,
Grafana, Splunk, Tomcat, Exchange, IIS, SharePoint, Citrix, ManageEngine,
WordPress and more.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Must be run as root | `sudo python3 netseeker.py` |
| No DCs found via SRV | Point /etc/resolv.conf to DC IP |
| selenium import failed | `sudo pip3 install selenium webdriver-manager --break-system-packages --ignore-installed urllib3` |
| Chrome failed to start | `sudo pip3 install webdriver-manager --break-system-packages --ignore-installed urllib3` |
| nmap not found | `sudo apt install nmap` |
| nslookup not found | `sudo apt install dnsutils` |
| DNS resolution slow | Increase `--batch-size 200` |

---

## Legal Notice
For authorized penetration testing only.
